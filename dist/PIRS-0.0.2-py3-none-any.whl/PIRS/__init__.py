from PIRS import rank

"""
The package PIRS consists of one module.  rank performs sorting of expression profiles to identify constitutive expression.
"""
