from PIRS import ranker

"""
The package PIRS consists of one module.  ranker performs sorting of expression profiles to identify constitutive expression.
"""
